function Meassage(){
    
    return(
        <p>
            Message
        </p>
    )

}
export default Meassage;