import "../styling/right.css";
function Right() {
  return (
    <div id="mainright">
      <div id="empty">
      </div>
      <div id="nonempty">
        <div id="msgs">
            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Ithadi Sushmitha
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>
            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Deepak
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>
            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Nitish nb
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>
            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Jerlin K
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>

            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Vishnu
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>

            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Nitin
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>

            <div class="lisgroup">
                <div id="list-left">
                    <img id="profilepic" src={"https://media.istockphoto.com/vectors/cartoon-angry-zombie-head-screaming-expression-halloween-vector-vector-id827616586?k=20&m=827616586&s=170667a&w=0&h=D0gfrMxzU5_mix60VpCcbYRquvH-gbvjVr3RM_3aikE="} />
                </div>
                <div id="list-middle">
                    <p id="profilename">
                        Koteswar Rao
                    </p>
                    <p id="profilecaption">
                        You sent a post
                    </p>
                </div>
                <div id="list-right">
                    <p id="date">
                        Sep 23
                    </p>
                </div>
            </div>


            
        </div>
      </div>
    </div>
  );
}
export default Right;
